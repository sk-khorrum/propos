# Animated love card

A Pen created on CodePen.io. Original URL: [https://codepen.io/rohitdharavath/pen/mxevwV](https://codepen.io/rohitdharavath/pen/mxevwV).

SVG + GSAP